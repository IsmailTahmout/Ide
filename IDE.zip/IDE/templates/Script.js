console.log(122333);
const editorval=document.querySelector('.editor')
const output=document.querySelector('.output')
const run =document.querySelector('.run')
run.onclick=function () {
  let request=new XMLHttpRequest()
  request.open("POST","http://0.0.0.0:5555/run",true)
  request.setRequestHeader("Content-type","application/json")
  request.setRequestHeader("accept","application/json")
  request.send(JSON.stringify({"code":editorval.value}))
request.onreadystatechange=function (){
  console.log(request.status);
  if (request.status==200){
    output.textContent=JSON.parse(request.responseText).response}
  else{
    const error=request.response
    output.innerHTML=error
  }}}